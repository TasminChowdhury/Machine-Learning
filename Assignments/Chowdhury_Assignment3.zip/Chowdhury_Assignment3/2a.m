%% Discriminant Analysis On the Fisher Iris Data
%
%%

% This file is from pmtk3.googlecode.com

loadData('heightWeight')
X = heightWeightData(1:end, 2:3);  % taking all rows, entire dataset
class = heightWeightData(1:end, 1); % classes 1/2
%[y, support] = canonizeLabels(labels);
types = {'quadratic', 'linear'};
for tt=1:length(types)
  model = discrimAnalysisFit(X, class, types{tt});
  h = plotDecisionBoundary(X, class, @(Xtest)discrimAnalysisPredict(model, Xtest));
  title(sprintf('Discrim. analysis of type %s', types{tt}));
  if ~isOctave
    legend(h, support, 'Location', 'NorthWest');
    set(gca, 'Xtick', 5:8, 'Ytick', 2:0.5:4);
  end
  xlabel('X_1'); ylabel('X_2');
end
