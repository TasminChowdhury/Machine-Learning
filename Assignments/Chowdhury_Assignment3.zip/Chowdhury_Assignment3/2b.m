%% Discriminant Analysis On the Fisher Iris Data
%
%%

% This file is from pmtk3.googlecode.com

loadData('heightWeight')
trainData = heightWeightData(1:180, 2:3);  % taking the features to train , all rows  
classes = heightWeightData(1:180, 1);      % and the classs 
testData = heightWeightData(181:end, 2:3); % rest are for testing
testclasses = heightWeightData(181:end, 1);
types = {'quadratic', 'linear'};
for tt=1:length(types)
  model = discrimAnalysisFit(trainData, classes, types{tt});
  prediction = discrimAnalysisPredict(model, testData); 
  
  correctlypredictedinstances = size(prediction,1) - sum(prediction ~= testclasses);
  accuracyRate = 100-(100*(mean(prediction ~= testclasses)))
  fprintf('%s, accuracyRate: %.2f%%\n, correctlypredictedinstances: %d \n', types{tt}, accuracyRate, correctlypredictedinstances);
  
  %plot graph
  h = plotDecisionBoundary(trainData,classes, @(testData)discrimAnalysisPredict(model, testData));
  title(sprintf('Discrim. analysis of type %s', types{tt}));
  if ~isOctave
    legend(h, support, 'Location', 'NorthWest');
    set(gca, 'Xtick', 5:8, 'Ytick', 2:0.5:4);
  end
  xlabel('X_1'); ylabel('X_2');
 
end

