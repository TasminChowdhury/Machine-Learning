%% Discriminant Analysis On the Fisher Iris Data
%
%%

% This file is from pmtk3.googlecode.com

loadData('fisherIrisData')
X = meas(1:end, 2:3);  % for illustrations use 2 species, feature 2 and feature 3 for all the instances
labels = species(1:end);
[y, support] = canonizeLabels(labels);
types = {'quadratic', 'linear', 'diag'};
for tt=1:length(types)
  model = discrimAnalysisFit(X, y, types{tt});
  h = plotDecisionBoundary(X, y, @(Xtest)discrimAnalysisPredict(model, Xtest));
  title(sprintf('Discrim. analysis of type %s', types{tt}));
  if ~isOctave
    legend(h, support, 'Location', 'NorthWest');
    set(gca, 'Xtick', 5:8, 'Ytick', 2:0.5:4);
  end
  xlabel('X_1'); ylabel('X_2');
end
6027
6029
6025
