data = load('fisherIrisSetosaData.txt'); 
sepalwidth_X=data(:,2);
sepalLength_Y=data(:,1);
%plot(sepalwidth_X,sepalLength_Y,'rx','MarkerSize',8); % Plot the data
%xlabel('Sepal Width'); % Set the x-axis label
%ylabel('Sepal Length'); % Set the y-axis label
tic ();
m= length(sepalLength_Y);
X = [ones(m,1) sepalwidth_X];
weight= zeros(2,1) %initializing wih zero 2*1 column vector
learning_rate=0.1;

prevC=Inf
iteration=0
while(1)

    x = X(:,2);
    h = weight(1) + (weight(2)*x);

    w0 = weight(1) - learning_rate * (1/m) * sum(h-sepalLength_Y);
    w1  = weight(2) - learning_rate * (1/m) * sum((h-sepalLength_Y) .* x);

    weight = [w0; w1];   
    %compute cost
    C = 0;            
    error   = (h - sepalLength_Y).^2;
    C = 1/(2*m) * sum(error);
    
    iteration =iteration +1
    if abs(prevC-C) < 10^-8
      break;
    end
    
    prevC=C;
end
  disp(iteration)
fprintf('Weight');
fprintf('%f %f \n', weight(1), weight(2));

elapsed_time = toc ();
disp(elapsed_time)