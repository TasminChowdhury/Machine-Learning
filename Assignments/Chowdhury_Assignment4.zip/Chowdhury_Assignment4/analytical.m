data = load('fisherIrisSetosaData.txt'); 
sepalwidth_X=data(:,2)
sepalLength_Y=data(:,1)
plot(sepalwidth_X,sepalLength_Y,'rx','MarkerSize',8); % Plot the data
xlabel('Sepal Width'); % Set the x-axis label
ylabel('Sepal Length'); % Set the y-axis label
len_x=length(sepalwidth_X);
X = [ones(len_x,1) sepalwidth_X];
%calculate weight
tic ();

w= (pinv(X'*X))*X'*sepalLength_Y
disp(w)
hold on;
plot(X(:,2),X*w,'-')
legend('Training data', 'Linear regression')
hold off
elapsed_time = toc ();
disp(elapsed_time)
