data = load('fisherIrisVersicolorVirginicaData.txt'); 
sepal_length= data(:,1);
petal_length= data(:,2);
species= data(:,3);
plot(sepal_length,petal_length,'rx','MarkerSize',8); % Plot the data
xlabel('Sepal Length'); % Set the x-axis label
ylabel('Petal Length'); % Set the y-axis label