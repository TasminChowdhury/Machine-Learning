data = load('fisherIrisVersicolorVirginicaData.txt'); 
data_class = data(:,3);
data_class = data_class-1;

trainData = data(1:80,1:2);  % taking the features to train , all rows  
trainclasses = data_class(1:80,:);      % and the classs 
testData = data(81:end, 1:2); % rest are for testing
testData = [ones(20,1) testData];
testclasses = data_class(81:end, :);

tic ();
m = length(trainData);
X = [ones(m,1) trainData];
weight= zeros(1,3); %initializing wih zero 2*1 column vector
tempWeight = zeros(1,3);
learning_rate=0.1;
iteration=0;
prevC=Inf;
%iteration
epoch=0;

disp("for epoch 1 initial training")
  for i=1:80
    x = X(i, 1:end)'; 
    Z = weight*x;
    y_hat= 1/(1 + exp(-Z));

    tempWeight(1)  = weight(1) - learning_rate * (y_hat-trainclasses(i)) * x(1);
    tempWeight(2)  = weight(2) - learning_rate * (y_hat-trainclasses(i)) * x(2);
    tempWeight(3)  = weight(3) - learning_rate * (y_hat-trainclasses(i)) * x(3);
    
    weight = tempWeight;  
    iteration=iteration+1;
  end
  predictedClasses = round(1./(1+exp(-(weight*testData'))));
  accuracy = (sum(predictedClasses==testclasses')/20)*100;
  printf("accuracy after epoch 1 is %f\n", accuracy);
  
   

for j = 2:20000
  printf("starting of epoch %d\n", j)
  for i=1:80
    x = X(i, 1:end)'; 
    Z = weight*x;
    y_hat= 1/(1 + exp(-Z));

    tempWeight(1)  = weight(1) - learning_rate * (y_hat-trainclasses(i)) * x(1);
    tempWeight(2)  = weight(2) - learning_rate * (y_hat-trainclasses(i)) * x(2);
    tempWeight(3)  = weight(3) - learning_rate * (y_hat-trainclasses(i)) * x(3);
    
    weight = tempWeight;  
    iteration=iteration+1;
  end
  predictedClasses = round(1./(1+exp(-(weight*testData'))));
  accuracy = (sum(predictedClasses==testclasses')/20)*100;
  printf("accuracy after epoch %d is %f\n", j, accuracy);
end
  
  
printf("Total iteration %d\n",iteration);
%elapsed_time = toc ();
printf("Total time", toc());




disp(elapsed_time)

