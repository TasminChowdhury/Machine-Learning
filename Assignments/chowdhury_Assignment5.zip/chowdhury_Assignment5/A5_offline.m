data = load('fisherIrisVersicolorVirginicaData.txt'); 
data_class = data(:,3);
data_class = data_class-1;

trainData = data(1:80,1:2);  
trainclasses = data_class(1:80,:);      
testData = data(81:end, 1:2); 
testData = [ones(20,1) testData];
testclasses = data_class(81:end, :);

tic ();
m = length(trainData);
X = [ones(m,1) trainData];
weight= zeros(1,3); 
tempWeight = zeros(1,3);
learning_rate=0.1;
iteration=0;
prevC=Inf;

while(1)
    Z = weight*X';
    y_hat= 1./(1 + exp(-Z));
    
    % update weight
    tempWeight(1)  = weight(1) - learning_rate * (1/m) * sum((y_hat-trainclasses') .* X'(1, 1:end));
    tempWeight(2)  = weight(2) - learning_rate * (1/m) * sum((y_hat-trainclasses') .* X'(2, 1:end));
    tempWeight(3)  = weight(3) - learning_rate * (1/m) * sum((y_hat-trainclasses') .* X'(3, 1:end));
    weight = tempWeight; 
    
    %compute cost          
    newC = (-1/m) * sum( trainclasses' .* log(y_hat) + (1 - trainclasses') .* log(1 - y_hat) );
    
    iteration=iteration+1;
   
    if abs(prevC-newC) < 10^-7
      break;
    end
    
    prevC=newC;
end

disp(weight);
disp(iteration);
predictedClasses = round(1./(1+exp(-(weight*testData'))))
accuracy = (sum(predictedClasses==testclasses')/20)*100
elapsed_time = toc ();
disp(elapsed_time)

