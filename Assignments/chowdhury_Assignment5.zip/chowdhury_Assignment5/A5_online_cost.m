data = load('fisherIrisVersicolorVirginicaData.txt'); 
data_class = data(:,3);
data_class = data_class-1;

trainData = data(1:80,1:2);  
trainclasses = data_class(1:80,:);   
testData = data(81:end, 1:2);
testData = [ones(20,1) testData];
testclasses = data_class(81:end, :);

tic ();
m = length(trainData);
X = [ones(m,1) trainData];
weight= zeros(1,3);
tempWeight = zeros(1,3);
learning_rate=1;
iteration=0;
prevC=Inf;

while(1)
  for i=1:80
    x = X(i, 1:end)'; 
    Z = weight*x;
    y_hat= 1/(1 + exp(-Z));

    tempWeight(1)  = weight(1) - learning_rate * (y_hat-trainclasses(i)) * x(1);
    tempWeight(2)  = weight(2) - learning_rate * (y_hat-trainclasses(i)) * x(2);
    tempWeight(3)  = weight(3) - learning_rate * (y_hat-trainclasses(i)) * x(3);
    
    weight = tempWeight;  
    iteration=iteration+1;
  end
   Z = weight*X';
   y_hat = 1./(1 + exp(-Z));
   %compute cost    
   newC = (-1/m) * sum( trainclasses' .* log(y_hat) + (1 - trainclasses') .* log(1 - y_hat) );
   disp(newC)
   if abs(prevC-newC) < 10^-2
     break;
   end
   prevC=newC;
end
disp(weight);
disp(iteration);
elapsed_time = toc ();

predictedClasses = round(1./(1+exp(-(weight*testData'))))
accuracy = (sum(predictedClasses==testclasses')/20)*100
disp(elapsed_time)

