data = load('fisherIrisData.txt'); 
trainData = data(1:120,1);  % Train Sepal length
trainSpecies = data(1:120,2);  % Train Sepal width

testData = data(121:150,1); % Test Sepal length
testSpecies = data(121:150,2); % Test Sepal width

model=svmtrain(trainSpecies, trainData,'-s 3 -t 2');

[predicted_label,accuracy,prob_estimates]=svmpredict(testSpecies,testData,model);