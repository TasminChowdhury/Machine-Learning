
data = load('fisherIrisData.txt'); 
trainData = data(1:120, [1 4]);
trainSpecies = data(1:120, [5]);
  
testData = data(121:150, [1 4]);
testSpecies = data(121:150, [5]);

model = svmtrain(trainSpecies, trainData,'-s 1 -t 2 '); 
[predicted_label,accuracy,prob_estimates]=svmpredict(testSpecies,testData,model);
